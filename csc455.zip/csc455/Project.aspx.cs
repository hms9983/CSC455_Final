﻿using System;
using System.Data;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;

public partial class Project : System.Web.UI.Page
{
    private object _message;

    protected void Page_Load(object sender, EventArgs e)
    {
        Label11.Text = "";
        Panel1.Visible = false;
        Panel2.Visible = false;
        Panel3.Visible = false;
        Panel4.Visible = false;
        Panel5.Visible = false;

        GridView1.Visible = false;
        GridView2.Visible = false;
        GridView3.Visible = false;
        GridView4.Visible = false;
        GridView5.Visible = false;
        GridView6.Visible = false;
        GridView7.Visible = false;
        GridView8.Visible = false;
        GridView9.Visible = false;
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Panel1.Visible = true;
        Label11.Text = "Add Member";
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        string connStr = "server=webdev.cislabs.uncw.edu; user =dnc2848;database=narayan6;password=LENnGIv3M;";
        MySql.Data.MySqlClient.MySqlConnection conn = new MySqlConnection(connStr);
        try
        {
            Console.WriteLine("Connecting to MySQL...");
            conn.Open();

            string rtn = "InsertMember";
             MySqlCommand cmd = new MySqlCommand(rtn, conn);
             cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@userId", TextBox1.Text);
            cmd.Parameters.AddWithValue("@password", TextBox2.Text);
            cmd.Parameters.AddWithValue("@name", TextBox3.Text);
            cmd.Parameters.AddWithValue("@address", TextBox4.Text);
            cmd.Parameters.AddWithValue("@phone", TextBox5.Text);
            cmd.Parameters.AddWithValue("@email", TextBox6.Text);
            MySqlDataReader rdr = cmd.ExecuteReader();
            
            while (rdr.Read())
            {
                Console.WriteLine(rdr[0] + " --- " + rdr[1]);
            }
            rdr.Close();
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.ToString());
        }

        conn.Close();
        Console.WriteLine("Done.");
    }



    protected void Button3_Click(object sender, EventArgs e)
    {
        GridView1.Visible = true;
        Label11.Text = "Current Auctions";
    }

    protected void Button4_Click(object sender, EventArgs e)
    {
        Label11.Text = "Finished Auctions";
        GridView2.Visible = true;
    }

    protected void Button5_Click(object sender, EventArgs e)
    {
        Label11.Text = "Auctions short by time";
        GridView3.Visible = true;
    }

    protected void Button6_Click(object sender, EventArgs e)
    {
        Label11.Text = "Auctions short by price";
        GridView4.Visible = true;
    }

    protected void Button7_Click(object sender, EventArgs e)
    {
        Label11.Text = "Get total price of items";
        GridView5.Visible = true;
    }

    protected void Button9_Click(object sender, EventArgs e)
    {
        string connStr = "server=webdev.cislabs.uncw.edu; user =dnc2848;database=narayan6;password=LENnGIv3M;";
        MySql.Data.MySqlClient.MySqlConnection conn = new MySqlConnection(connStr);
        try
        {
            Console.WriteLine("Connecting to MySQL...");
            conn.Open();

            string rtn = "InsertBid";

            DateTime now = DateTime.Now;
            Console.WriteLine(now);

            MySqlCommand cmd = new MySqlCommand(rtn, conn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@buyerId", TextBox7.Text);
            cmd.Parameters.AddWithValue("@ino", TextBox8.Text);
            cmd.Parameters.AddWithValue("@price", TextBox9.Text);
            cmd.Parameters.AddWithValue("@qtyWanted", TextBox10.Text);
            cmd.Parameters.AddWithValue("@bidTime", now);
            MySqlDataReader rdr = cmd.ExecuteReader();

            while (rdr.Read())
            {
                Console.WriteLine(rdr[0] + " --- " + rdr[1]);
            }
            rdr.Close();
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.ToString());
        }

        conn.Close();
        Console.WriteLine("Done.");
    }

    protected void Button8_Click(object sender, EventArgs e)
    {
        Label11.Text = "Insert Bid";
        Panel2.Visible = true;
    }

    protected void Button10_Click(object sender, EventArgs e)
    {
        Label11.Text = "Buyer Ratings";
        GridView6.Visible = true;
    }

    protected void Button11_Click(object sender, EventArgs e)
    {
        Label11.Text = "User Ratings";
        GridView7.Visible = true;
    }

    protected void Button12_Click(object sender, EventArgs e)
    {
        Label11.Text = "Top Seller";
        GridView8.Visible = true;
    }

    protected void Button13_Click(object sender, EventArgs e)
    {
        Label11.Text = "Insert Item";
        Panel3.Visible = true;
    }

    protected void Button14_Click(object sender, EventArgs e)
    {
        string connStr = "server=webdev.cislabs.uncw.edu; user =dnc2848;database=narayan6;password=LENnGIv3M;";
        MySql.Data.MySqlClient.MySqlConnection conn = new MySqlConnection(connStr);
        try
        {
            Console.WriteLine("Connecting to MySQL...");
            conn.Open();

            string rtn = "InsertItem";
            MySqlCommand cmd = new MySqlCommand(rtn, conn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@ino", TextBox11.Text);
            cmd.Parameters.AddWithValue("@category", TextBox12.Text);
            cmd.Parameters.AddWithValue("@title", TextBox13.Text);
            cmd.Parameters.AddWithValue("@description", TextBox14.Text);
            cmd.Parameters.AddWithValue("@sellerId", TextBox15.Text);
            cmd.Parameters.AddWithValue("@quantity", TextBox16.Text);
            cmd.Parameters.AddWithValue("@startPrice", TextBox17.Text);
            cmd.Parameters.AddWithValue("@bidIncrement", TextBox18.Text);
            cmd.Parameters.AddWithValue("@lastBid", TextBox19.Text);
            cmd.Parameters.AddWithValue("@closeTime", TextBox20.Text);
            MySqlDataReader rdr = cmd.ExecuteReader();

            while (rdr.Read())
            {
                Console.WriteLine(rdr[0] + " --- " + rdr[1]);
            }
            rdr.Close();
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.ToString());
        }

        conn.Close();
        Console.WriteLine("Done.");
    }

    protected void Button16_Click(object sender, EventArgs e)
    {
        string connStr = "server=webdev.cislabs.uncw.edu; user =dnc2848;database=narayan6;password=LENnGIv3M;";
        MySql.Data.MySqlClient.MySqlConnection conn = new MySqlConnection(connStr);
        try
        {
            Console.WriteLine("Connecting to MySQL...");
            conn.Open();

            string rtn = "InsertRatings";
            MySqlCommand cmd = new MySqlCommand(rtn, conn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@ino", TextBox21.Text);
            cmd.Parameters.AddWithValue("@buyerId", TextBox22.Text);
            cmd.Parameters.AddWithValue("@sellerId", TextBox23.Text);
            cmd.Parameters.AddWithValue("@sComment", TextBox24.Text);
            cmd.Parameters.AddWithValue("@bComment", TextBox25.Text);
            cmd.Parameters.AddWithValue("@sScale", TextBox26.Text);
            cmd.Parameters.AddWithValue("@bScale", TextBox27.Text);
            MySqlDataReader rdr = cmd.ExecuteReader();

            while (rdr.Read())
            {
                Console.WriteLine(rdr[0] + " --- " + rdr[1]);
            }
            rdr.Close();
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.ToString());
        }

        conn.Close();
        Console.WriteLine("Done.");
    }

    protected void Button15_Click(object sender, EventArgs e)
    {
        Label11.Text = "Insert Ratings";
        Panel4.Visible = true;
    }

    protected void Button18_Click(object sender, EventArgs e)
    {
        string connStr = "server=webdev.cislabs.uncw.edu; user =dnc2848;database=narayan6;password=LENnGIv3M;";
        MySql.Data.MySqlClient.MySqlConnection conn = new MySqlConnection(connStr);
        try
        {
            Console.WriteLine("Connecting to MySQL...");
            conn.Open();

            string rtn = "InsertShipping";
            MySqlCommand cmd = new MySqlCommand(rtn, conn);
            cmd.CommandType = CommandType.StoredProcedure;

            cmd.Parameters.AddWithValue("@ino", TextBox28.Text);
            cmd.Parameters.AddWithValue("@shipType", TextBox29.Text);
            cmd.Parameters.AddWithValue("@shipPrice", TextBox30.Text);
            MySqlDataReader rdr = cmd.ExecuteReader();

            while (rdr.Read())
            {
                Console.WriteLine(rdr[0] + " --- " + rdr[1]);
            }
            rdr.Close();
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.ToString());
        }

        conn.Close();
        Console.WriteLine("Done.");
    }

    protected void Button17_Click(object sender, EventArgs e)
    {
        Label11.Text = "Insert Shipping";
        Panel5.Visible = true;
    }

    protected void Button19_Click(object sender, EventArgs e)
    {
        Label11.Text = "Seller Rating";
        GridView9.Visible = true;
    }
}

